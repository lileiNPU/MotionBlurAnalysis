function Codes=Extract_LBP_Color_Video(Faces,r,v,mapping,bloc,overlap,mode,space,features,norm)
for j=1:size(Faces,2)
    im=Faces{j};
    if strcmp(space, 'HSV')
        im = rgb2hsv(im);
    end
    if strcmp(space, 'YCbCr')
        im = rgb2ycbcr(im);
    end
    %% LBP Features
    if(strcmp(features,'LBPMS')||strcmp(features,'LBP')||strcmp(features,'LBP256'))
        code=[];
        for l=1:size(im,3)
            code=[code Extract_LBP_Image(im(:,:,l),r,v,mapping,bloc,overlap,mode,norm)];
        end
    end
    %%
    Codes(j,:)=code;
end   


 