function Y = vl_nnlossEucDis(X, dzdy, varargin)
% EucDis
cost = X.^2;
if nargin <= 1 || isempty(dzdy)  
    Y = sum(cost(:));    
else
    Y = 2 * dzdy * X; 
end  