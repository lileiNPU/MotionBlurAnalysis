function y = vl_nndehazeresult(inputs, dzdy, varargin)
delta = 1;
HazeImg = inputs{1};
t = inputs{2};
t_matrix(:, :, 1, :) = t; 
t_matrix(:, :, 2, :) = t; 
t_matrix(:, :, 3, :) = t;
A = inputs{3};
A_matrix = ones(size(HazeImg));
for i = 1 : length(A)
    A_matrix(:, :, 1, i) = A{i}(1) * A_matrix(:, :, 1, i);
    A_matrix(:, :, 2, i) = A{i}(2) * A_matrix(:, :, 2, i);
    A_matrix(:, :, 3, i) = A{i}(3) * A_matrix(:, :, 3, i);
end
if nargin < 2
    t_matrix = max(abs(t_matrix), 0.1).^delta;  
    R = bsxfun(@rdivide, (HazeImg(:, :, 1, :) -  A_matrix(:, :, 1, :)), t_matrix(:, :, 1, :)) +  A_matrix(:, :, 1, :);  
    G = bsxfun(@rdivide, (HazeImg(:, :, 2, :) -  A_matrix(:, :, 2, :)), t_matrix(:, :, 2, :)) +  A_matrix(:, :, 2, :);  
    B = bsxfun(@rdivide, (HazeImg(:, :, 3, :) -  A_matrix(:, :, 3, :)), t_matrix(:, :, 3, :)) +  A_matrix(:, :, 3, :);  
    y = cat(3, R, G, B);
else
    y{1} = {};
    t_matrix = abs(t_matrix); 
    selec = (t_matrix > 0.1);
    t_matrix = max(t_matrix, 0.1); 
    y1 = selec(:, :, 1, :) .* ((A_matrix(:, :, 1, :) - HazeImg(:, :, 1, :)) ./ (t_matrix(:, :, 1, :)).^2) .* dzdy(:, :, 1, :);
    y2 = selec(:, :, 2, :) .* ((A_matrix(:, :, 2, :) - HazeImg(:, :, 2, :)) ./ (t_matrix(:, :, 2, :)).^2) .* dzdy(:, :, 2, :);
    y3 = selec(:, :, 3, :) .* ((A_matrix(:, :, 3, :) - HazeImg(:, :, 3, :)) ./ (t_matrix(:, :, 3, :)).^2) .* dzdy(:, :, 3, :);
    y{2} = y1 + y2 + y3;
    y{3} = {};
end