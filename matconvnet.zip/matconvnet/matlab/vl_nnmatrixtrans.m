function y = vl_nnmatrixtrans(inputs, dzdy, varargin)
temp = inputs{1};
if nargin < 2 
    y = reshape(temp, [1, 1, size(temp,2), size(temp,4)]);
else
    y{1} = reshape(dzdy, [1, size(temp,2), 1, size(temp,4)]);
end