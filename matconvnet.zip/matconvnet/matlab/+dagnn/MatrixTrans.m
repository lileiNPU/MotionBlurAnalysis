classdef MatrixTrans < dagnn.ElementWise

  methods
    function outputs = forward(obj, inputs, params)
      outputs{1} = vl_nnmatrixtrans(inputs) ;
    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
      derInputs = vl_nnmatrixtrans(inputs, derOutputs{1}) ;
      derParams = {} ;
    end
    
  end
end
