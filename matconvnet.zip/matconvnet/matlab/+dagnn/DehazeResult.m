classdef DehazeResult < dagnn.ElementWise

  methods
    function outputs = forward(obj, inputs, params)
      outputs{1} = vl_nndehazeresult(inputs) ;
    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
      derInputs = vl_nndehazeresult(inputs, derOutputs{1}) ;
      derParams = {} ;
    end
    
  end
end
