classdef Upsample < dagnn.ElementWise
  
  properties (Transient)
      inputSizes = {}
  end
    
  methods
    function outputs = forward(obj, inputs, params)
      outputs{1} = vl_nnupsample(inputs) ;
      obj.inputSizes = cellfun(@size, inputs, 'UniformOutput', false) ;
    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
      derInputs = vl_nnupsample(inputs, derOutputs{1}, 'inputSizes', obj.inputSizes) ;
      derParams = {} ;
    end
  end
end
