classdef WeightLossSum < dagnn.ElementWise

  methods
    function outputs = forward(obj, inputs, params)
      outputs{1} = vl_nnweightlosssum(inputs) ;
    end

    function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
      derInputs = vl_nnweightlosssum(inputs, derOutputs{1}) ;
      derParams = {} ;
    end
    
  end
end
