function y = vl_nnweightlosssum(inputs, dzdy, varargin)
objective_fog_water = (1/3) * inputs{1};
objective_water_air = inputs{2};
beta = inputs{3};
if nargin < 2
    y = beta * objective_fog_water + (1 - beta) *  objective_water_air;
else
    y{1} = beta * ones(size(objective_fog_water)) * dzdy;
    y{2} = (1 - beta) * ones(size(objective_water_air)) * dzdy;
    y{3} = (objective_fog_water - objective_water_air) * dzdy;
end