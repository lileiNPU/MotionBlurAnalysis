function y = vl_nnupsample(inputs, dzdy, varargin)
if nargin < 2  
    X = inputs{1};
    y = zeros(size(X, 1) * 2, size(X, 2) * 2, size(X, 3), size(X, 4), 'like', X);
    y(1:2:end, 1:2:end, :, :) = X;
    y(1:2:end, 2:2:end, :, :) = X;
    y(2:2:end, 1:2:end, :, :) = X;
    y(2:2:end, 2:2:end, :, :) = X;  
else
    X = dzdy;
    y{1} = vl_nnpool(X, [2 2], 'pad', 0, 'stride', 2, 'method', 'avg') * 4;
end
